import sqlite3
from flask import Flask, render_template, request

## Flask app
app = Flask(__name__)
## Connect to sqlite3 database
connection = sqlite3.connect("app.db", check_same_thread=False)
## Database cursor
cursor = connection.cursor()

## LOGIN: Verify user
def verify(username, password):
    ## SELECT query to get user
    cursor.execute("SELECT COUNT(*) FROM users WHERE username = '%s' AND password_hash = '%s'" % (username, password))
    ## return result
    return cursor.fetchone()[0]

## LOGOUT
## TODO: Create logout feature

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("index.html")
    else:
        ## Check if username and password are empty
        if not request.form.get("username"):
            return render_template("index.html")
        elif not request.form.get("password"):
            return render_template("index.html")

        ## Get username and password values from request
        username = request.form.get("username")
        password = request.form.get("password") 

        ## Verify user credentials
        result = verify(username, password)

        if result == 1:
            return "<body style='background-color: rgba(253, 227, 113, 0.322); !important;'><h1>Authenticated: Access Granted</h1></body>"
        else:
            return "<body style='background-color: rgba(253, 227, 113, 0.322); !important;'><h1>Error: Check Credentials</h1></body>"

@app.route("/register", methods=["GET", "POST"])
def register():
    ## TODO: Create register feature
    ## Check db for existing username
    ## Password must be at least 8 characters
    ## Username must not be "ADMIN"
    pass

@app.route("/dashboard")
def dashboard():
    ## TODO: Create authorized user dashboard
    pass


if __name__ == "__main__":
    ## Run app in debug mode
    app.run(debug=True)